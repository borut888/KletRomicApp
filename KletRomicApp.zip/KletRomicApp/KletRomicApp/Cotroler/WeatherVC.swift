//
//  WeatherVC.swift
//  KletRomicApp
//
//  Created by Borut on 06/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import Alamofire

class WeatherVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    let API_KEY = "1550b9c6defe4a725898c59da8735314"
    let URL_KUTINA_DAILY = "https://api.openweathermap.org/data/2.5/forecast/daily?q=kutina,cro&appid=42a1771a0b787bf12e734ada0cfc80cb"
    
    @IBOutlet weak var tableViewWeather: UITableView!
    @IBOutlet weak var currentDateLbl: UILabel!
    @IBOutlet weak var currentTempLbl: UILabel!
    @IBOutlet weak var currentLocationLbl: UILabel!
    @IBOutlet weak var currentWeatherImg: UIImageView!
    @IBOutlet weak var currentWeatherTypeLbl: UILabel!
    
    var currentWeather: WeatherModel!
    var tableViewUIUpdate : TableViewWeatherModel!
    var dailyForecasts = [TableViewWeatherModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableViewWeather.delegate = self
        tableViewWeather.dataSource = self
        
        currentWeather = WeatherModel()
        
        currentWeather.downloadWeatherDetails {
            self.dowloadDataForTableView {
                self.updateUI()
            }
        }
        
    }
    func dowloadDataForTableView(completed: @escaping DownloadComplete) {
        let forecastTableView = URL(string: URL_KUTINA_DAILY)
        Alamofire.request(forecastTableView!).responseJSON { response in
            let result = response.result
            
            if let dict = result.value as? Dictionary<String, AnyObject> {
                if let list = dict["list"] as? [Dictionary< String, AnyObject>] {
                    for obj in list {
                        let dailyForecast = TableViewWeatherModel(weatherDict: obj)
                        self.dailyForecasts.append(dailyForecast)
                    }
                    self.dailyForecasts.remove(at: 0)
                    self.tableViewWeather.reloadData()
                }
            }
            completed()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dailyForecasts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableViewWeather.dequeueReusableCell(withIdentifier: "weatherCellIndentifier") as? DailyForecastForTableViewCell {
            let forecast = dailyForecasts[indexPath.row]
            cell.configureCell(dailyForecast: forecast)
            return cell
        }else {
            return DailyForecastForTableViewCell()
        }
    
    }
    
    func updateUI() {
        //currentLocationLbl.text = currentWeather.cityName
        currentWeatherTypeLbl.text = currentWeather.weatherType
        currentDateLbl.text = currentWeather.date
        currentTempLbl.text = "\(currentWeather.currentTemp)°"
        currentWeatherImg.image = UIImage(named: currentWeather.weatherType)
    }
    
}
