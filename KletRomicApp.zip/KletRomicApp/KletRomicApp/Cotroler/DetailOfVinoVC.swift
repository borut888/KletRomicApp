//
//  DetailOfVinoVC.swift
//  KletRomicApp
//
//  Created by Borut on 11/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import QuartzCore

class DetailOfVinoVC: UIViewController {

    @IBOutlet weak var btnForDissmising: UIButton!
    @IBOutlet weak var vinoImage: UIImageView!
    @IBOutlet weak var vinoDetailLbl: UILabel!
    var currentVino : VinaModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let vinoImg = UIImage(named: (currentVino?.imageVino)!)
        vinoImage.image = vinoImg
        vinoDetailLbl.text = currentVino?.detailVino
        vinoDetailLbl.layer.masksToBounds = true
        vinoDetailLbl.layer.cornerRadius = 30
        btnForDissmising.layer.masksToBounds = true
        btnForDissmising.layer.cornerRadius = 15
        btnForDissmising.layer.borderWidth = 2.0
        
    }
    @IBAction func dissmisBtn(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
}
