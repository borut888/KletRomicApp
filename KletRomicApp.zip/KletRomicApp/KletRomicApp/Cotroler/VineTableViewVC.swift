//
//  VineTableViewVC.swift
//  KletRomicApp
//
//  Created by Borut on 09/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class VineTableViewVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    let vinaForTable = ["Frankovka", "Grasevina", "Pinot bijeli", "Skrlet"]
    @IBOutlet weak var vineTableView: UITableView!
    var vina = [VinaModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var vino = VinaModel(nameVino: "Frankovka", imageVino: "Frankovka", detailVino: "Frankovka je sorta sa porijeklom iz središnje Europe, te ju svojataju kao autohtonu skoro sve države sa ovog područja, uključujući i Hrvatsku. Vino je intenzivne rubin crvene boje, srednje gustoće i osvježavajućeg voćnog okusa. Prosječan postotak alkohola za ovu sortu je 12%. Poslužuje se blago rashlađeno (16°C) uz jača tj. pikantnija jela")
        vina.append(vino)
        vino = VinaModel(nameVino: "Graševina", imageVino: "Grasevina", detailVino: "Graševina je vino žuto-zelene kristalno bistre boje. Miris je ugodan, cvjetni i voćni, uz skladan i pun okus. Izuzetna pitkost i svježina čini ga najpopularnijim vinom u Hrvatskoj. Poslužiti uz predjela, tjestenine, jela od bijelog mesa i bijele ribe, ohlađeno na 8-10°C.")
        vina.append(vino)
        vino = VinaModel(nameVino: "Pinot bijeli", imageVino: "Pinot bijeli", detailVino: "Pinot bijeli (Bijeli pinot, Pinot blanc, Burgundac bijeli, Burgundac, Weissburgunder, Weißer Burgunder) je stara sorta grožđa, rasprostranjena uglavnom u Njemačkoj i Italiji, a u Hrvatskoj u Slavoniji. Vjerojatno je nastao spontanim križanjem sivog i crnogpinota. Vino je slamnato žute boje sa zelenkastim odsjajem. Laganog je okusa koji aromom podsjeća na jabuku i breskvu. Ima srednji ili veći sadržaj kiselina i visok sadržaj alkohola. Starenjem dobiva zlatnu boju.")
        vina.append(vino)
        vino = VinaModel(nameVino: "Škrlet", imageVino: "Skrlet", detailVino: "Škrlet je sorta bijelog grožđa nepoznata podrijetla, ali s obzirom na to da se pretežito uzgaja u podregijama Moslavinai Pokuplje.  Sadržaj šećera u grožđu u pravilu nije visok (obično oko 16 %, a samo u dobrim godinama dostigne i 18 %), ali je zato sa sadržajem kiselina bogata (od 8 pa i do 11g/l). Izuzetno ugodna aroma i skladan okus ovoga vina kada je ono proizvedeno u skladu sa odgovarajućim tehnološkim postupkom")
        vina.append(vino)

        vineTableView.delegate = self
        vineTableView.dataSource  = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vina.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = vineTableView.dequeueReusableCell(withIdentifier: "vineCell") as! VineTableViewCell
//        cell.vineImg.image = UIImage(named: vinaForTable[indexPath.row] + ".jpg")
//        cell.vineNameLbl.text = vinaForTable[indexPath.row]
        
        let currentVino = vina[indexPath.row]
        cell.vineNameLbl.text = currentVino.nameVino
        cell.vineImg.image = UIImage(named: currentVino.imageVino)
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let navigaton =  segue.destination as! DetailOfVinoVC
        if let indexPath = self.vineTableView.indexPathForSelectedRow {
            let selectedRow = vina[indexPath.row]
            navigaton.currentVino = selectedRow
        }
    }

}
