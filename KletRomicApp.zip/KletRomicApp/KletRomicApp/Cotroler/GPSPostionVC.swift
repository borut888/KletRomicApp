//
//  GPSPostionVC.swift
//  KletRomicApp
//
//  Created by Borut on 25/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import MapKit

class GPSPostionVC: UIViewController {

    @IBOutlet var lblTitle: UIView!
    @IBOutlet weak var mapKitOutlet: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let span: MKCoordinateSpan = MKCoordinateSpanMake(0.1, 0.1)
        let location: CLLocationCoordinate2D = CLLocationCoordinate2DMake(45.519788, 16.781471)
        let region:MKCoordinateRegion = MKCoordinateRegionMake(location, span)
        mapKitOutlet.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = "Klet Romić"
        annotation.subtitle = "Dobrodošli"
        mapKitOutlet.addAnnotation(annotation)
        
    }
}
