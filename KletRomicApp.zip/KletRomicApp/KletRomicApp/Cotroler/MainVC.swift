//
//  MainVC.swift
//  KletRomicApp
//
//  Created by Borut on 16/12/2017.
//  Copyright © 2017 Borut. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class MainVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableViewSideMenu: UITableView!
    @IBOutlet weak var imgSlikaGrozdje: UIImageView!
    @IBOutlet weak var txtViewOpisKleti: UITextView!
    @IBOutlet weak var lblNaslovna: UILabel!
    @IBOutlet weak var sideMenuConstraint: NSLayoutConstraint!
    @IBOutlet weak var sideMenuView: UIView!
    @IBOutlet weak var faceBtn: UIButton!
    @IBOutlet weak var btnVideo: UIBarButtonItem!
    @IBOutlet weak var imgGrozdje2: UIImageView!
    @IBOutlet weak var imgVina: UIImageView!
    
    var currentWeather: WeatherModel!
    var arrayForMenu = ["O nama", "Prognoza", "Naša vina","Gdje smo","Kontakt"]
    var viewIDs = ["ONamaIdentifier","prognozaIdIdentifier", "vinaIdIdentifier", "idGdjeSmo","idContactUS"]
    var isSideMenuHidden = true
    var playerController = AVPlayerViewController()
    var player:AVPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Klet Romić"
        self.navigationController?.navigationBar.titleTextAttributes = [ NSAttributedStringKey.font: UIFont.systemFont(ofSize: 17, weight: UIFont.Weight.light)]
        tableViewSideMenu.delegate = self
        tableViewSideMenu.dataSource = self
        
        sideMenuView.layer.shadowOpacity = 1
        sideMenuView.layer.shadowRadius = 10

        currentWeather = WeatherModel()
        currentWeather.downloadWeatherDetails {
            //setup UI
        }
        faceBtn.layer.masksToBounds = true
        faceBtn.layer.cornerRadius = 15
        faceBtn.layer.borderWidth = 2.0
        
        imgSlikaGrozdje.layer.masksToBounds = true
        imgSlikaGrozdje.layer.cornerRadius = 15
        imgSlikaGrozdje.layer.borderWidth = 2.0
        
        imgGrozdje2.layer.masksToBounds = true
        imgGrozdje2.layer.cornerRadius = 15
        imgGrozdje2.layer.borderWidth = 2.0
        
        imgVina.layer.masksToBounds = true
        imgVina.layer.cornerRadius = 30
        imgVina.layer.borderWidth = 2.0
        
        let videoString:String? = Bundle.main.path(forResource: "romicKletVideo", ofType: "3gp")
        if let url = videoString {
            let videoURL = NSURL(fileURLWithPath: url)
            self.player = AVPlayer(url: videoURL as URL)
            self.playerController.player = self.player
        }
    }
    
    //protokoli za tableVIew
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayForMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewSideMenu.dequeueReusableCell(withIdentifier: "customCell", for: indexPath) as! MenuTableViewCell
            cell.lblMenuDetails.text = arrayForMenu[indexPath.row]
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: viewIDs[indexPath.row], sender: self)
        
    }
    @IBAction func menuBtn(_ sender: UIButton) {
        
        if isSideMenuHidden {
            sideMenuConstraint.constant = 0
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
                self.lblNaslovna.minimumScaleFactor = 0.3
                self.imgSlikaGrozdje.isHidden = true
            })
        } else {
            sideMenuConstraint.constant = -170
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
                self.imgSlikaGrozdje.isHidden = false
            })
        }
        isSideMenuHidden = !isSideMenuHidden
    }
    @IBAction func faceBtnPressed(_ sender: Any) {
        guard let url = URL(string: "https://www.facebook.com/Klet-Romi%C4%87-854705918009561/") else {
            return //be safe
        }
        
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url)
        }
    }
    
    @IBAction func btnVideoPressed(_ sender: Any) {
        self.present(self.playerController, animated: true) {
            self.playerController.player?.play()
        }
    }
    
    

}
