//
//  VineTableViewCell.swift
//  KletRomicApp
//
//  Created by Borut on 09/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class VineTableViewCell: UITableViewCell {

    @IBOutlet weak var vineImg: UIImageView!
    @IBOutlet weak var vineNameLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
