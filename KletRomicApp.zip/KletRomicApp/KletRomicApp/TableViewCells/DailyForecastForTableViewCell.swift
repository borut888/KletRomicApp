//
//  DailyForecastForTableViewCell.swift
//  KletRomicApp
//
//  Created by Borut on 08/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class DailyForecastForTableViewCell: UITableViewCell {
    @IBOutlet weak var weatherImg: UIImageView!
    @IBOutlet weak var dayLbl: UILabel!
    @IBOutlet weak var weatherTypeLbl: UILabel!
    @IBOutlet weak var highTempLbl: UILabel!
    @IBOutlet weak var lowTempLbl: UILabel!
    
    
    func configureCell(dailyForecast: TableViewWeatherModel) {
        lowTempLbl.text = "\(dailyForecast.lowTemp)"
        highTempLbl.text = "\(dailyForecast.highTemp)"
        weatherTypeLbl.text = dailyForecast.weatherType
        weatherImg.image = UIImage(named: dailyForecast.weatherType)
        dayLbl.text = dailyForecast.date
    }

}
