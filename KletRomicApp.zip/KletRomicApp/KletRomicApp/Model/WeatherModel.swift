//
//  WeatherModel.swift
//  KletRomicApp
//
//  Created by Borut on 07/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import Alamofire
import Foundation

let URL_KUTINA_TODAY = "http://api.openweathermap.org/data/2.5/weather?q=kutina,cro&appid=1550b9c6defe4a725898c59da8735314"

typealias DownloadComplete = () -> ()

class WeatherModel {
    var _cityName : String!
    var _date: String!
    var _weatherType: String!
    var _currentTemp: Double!
    
    var cityName: String {
        if _cityName == nil {
            _cityName = ""
        }
        return _cityName
    }
    
    var date: String {
        if _date == nil {
            _date = ""
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .long
        dateFormatter.timeZone = .none
        let currentDate = dateFormatter.string(from: Date())
        self._date = "Danas \(currentDate)"
        return _date
    }
    
    var weatherType: String {
        if _weatherType == nil {
            _weatherType = ""
        }
        return _weatherType
    }
    
    var currentTemp: Double {
        if _currentTemp == nil {
            _currentTemp = 0.0
        }
        return _currentTemp
    }
    
    func downloadWeatherDetails(completed: @escaping DownloadComplete) {
        let currentWeatherUrl = URL(string: URL_KUTINA_TODAY)!
        Alamofire.request(currentWeatherUrl).responseJSON { response in
            let result = response.result
            if let dict = result.value as? Dictionary<String, AnyObject>{
                
                if let name = dict["name"] as? String {
                    self._cityName = name.capitalized
                    
                }
                
                if let weather = dict["weather"] as? [Dictionary<String, AnyObject>] {
                    //ovdje stavljamo [0] zato sto je to prvi dictionary u array, drugi dictionary bi imao [1]. Moze ih bit vise u listi
                    if let main = weather[0]["main"] as? String {
                        self._weatherType = main.capitalized
                        print(self._weatherType)
                    }
                }
                
                if let main = dict["main"] as? Dictionary<String, AnyObject> {
                    if let temp = main["temp"] as? Double {
                        self._currentTemp = temp - 273.15
                    
                    }
                }
            }
            // funckija completed se izvrsava kad zavrsi parsiranje
            completed()
        }
    }

}

