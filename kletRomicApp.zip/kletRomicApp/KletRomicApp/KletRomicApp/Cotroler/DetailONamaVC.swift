//
//  DetailONamaVC.swift
//  KletRomicApp
//
//  Created by Borut on 05/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class DetailONamaVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "O Nama";
    }

}
