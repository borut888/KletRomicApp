//
//  VineTableViewVC.swift
//  KletRomicApp
//
//  Created by Borut on 09/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class VineTableViewVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    let vinaForTable = ["Frankovka", "Grasevina", "Pinot bijeli", "Skrlet"]
    @IBOutlet weak var vineTableView: UITableView!
    var vina = [VinaModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var vino = VinaModel(nameVino: "Frankovka", imageVino: "Frankovka", detailVino: "ovo vino je totalni vrh, nesto najboljena svijeu lallalallala i jos bolje i treba ga pit i to je to")
        vina.append(vino)
        vino = VinaModel(nameVino: "Graševina", imageVino: "Grasevina", detailVino: "ovo vino je totalni vrh, nesto najboljena svijeu lallalallala i jos bolje i treba ga pit i to je to")
        vina.append(vino)
        vino = VinaModel(nameVino: "Pinot bijeli", imageVino: "Pinot bijeli", detailVino: "ovo vino je totalni vrh, nesto najboljena svijeu lallalallala i jos bolje i treba ga pit i to je to")
        vina.append(vino)
        vino = VinaModel(nameVino: "Škrlet", imageVino: "Skrlet", detailVino: "ovo vino je totalni vrh, nesto najboljena svijeu lallalallala i jos bolje i treba ga pit i to je to")
        vina.append(vino)

        vineTableView.delegate = self
        vineTableView.dataSource  = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vina.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = vineTableView.dequeueReusableCell(withIdentifier: "vineCell") as! VineTableViewCell
//        cell.vineImg.image = UIImage(named: vinaForTable[indexPath.row] + ".jpg")
//        cell.vineNameLbl.text = vinaForTable[indexPath.row]
        
        let currentVino = vina[indexPath.row]
        cell.vineNameLbl.text = currentVino.nameVino
        cell.vineImg.image = UIImage(named: currentVino.imageVino)
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let navigaton =  segue.destination as! DetailOfVinoVC
        if let indexPath = self.vineTableView.indexPathForSelectedRow {
            let selectedRow = vina[indexPath.row]
            navigaton.currentVino = selectedRow
        }
    }

}
