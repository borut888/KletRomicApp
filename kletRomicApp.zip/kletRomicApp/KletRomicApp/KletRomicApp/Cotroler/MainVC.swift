//
//  MainVC.swift
//  KletRomicApp
//
//  Created by Borut on 16/12/2017.
//  Copyright © 2017 Borut. All rights reserved.
//

import UIKit

class MainVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableViewSideMenu: UITableView!
    @IBOutlet weak var imgSlikaGrozdje: UIImageView!
    @IBOutlet weak var txtViewOpisKleti: UITextView!
    @IBOutlet weak var lblNaslovna: UILabel!
    @IBOutlet weak var sideMenuConstraint: NSLayoutConstraint!
    @IBOutlet weak var sideMenuView: UIView!
    
    var currentWeather: WeatherModel!
    
    var arrayForMenu = ["O nama", "Prognoza", "Naša vina"]
    var viewIDs = ["ONamaIdentifier","prognozaIdIdentifier", "vinaIdIdentifier"]
    var isSideMenuHidden = true
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewSideMenu.delegate = self
        tableViewSideMenu.dataSource = self
        
        sideMenuView.layer.shadowOpacity = 1
        sideMenuView.layer.shadowRadius = 10
        
        currentWeather = WeatherModel()
        currentWeather.downloadWeatherDetails {
            //setup UI
        }
        
    
        
    }
    
    //protokoli za tableVIew
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayForMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewSideMenu.dequeueReusableCell(withIdentifier: "customCell", for: indexPath) as! MenuTableViewCell
            cell.lblMenuDetails.text = arrayForMenu[indexPath.row]
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: viewIDs[indexPath.row], sender: self)
        
    }
    @IBAction func menuBtn(_ sender: UIButton) {
        
        if isSideMenuHidden {
            sideMenuConstraint.constant = 0
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
                self.lblNaslovna.minimumScaleFactor = 0.3
                self.imgSlikaGrozdje.isHidden = true
            })
        } else {
            sideMenuConstraint.constant = -170
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
                self.imgSlikaGrozdje.isHidden = false
            })
        }
        isSideMenuHidden = !isSideMenuHidden
    }
    
    

}
