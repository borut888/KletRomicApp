//
//  DetailOfVinoVC.swift
//  KletRomicApp
//
//  Created by Borut on 11/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class DetailOfVinoVC: UIViewController {

    @IBOutlet weak var vinoImage: UIImageView!
    @IBOutlet weak var vinoDetailLbl: UILabel!
    var currentVino : VinaModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let vinoImg = UIImage(named: (currentVino?.imageVino)!)
        vinoImage.image = vinoImg
        vinoDetailLbl.text = currentVino?.detailVino
    }
    @IBAction func dissmisBtn(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
}
