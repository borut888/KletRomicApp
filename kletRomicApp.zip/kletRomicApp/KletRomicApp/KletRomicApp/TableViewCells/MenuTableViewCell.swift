//
//  MenuTableViewCell.swift
//  KletRomicApp
//
//  Created by Borut on 06/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit

class MenuTableViewCell: UITableViewCell {

    @IBOutlet weak var vineImage: UIImageView!
    @IBOutlet weak var lblMenuDetails: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
