//
//  VinaModel.swift
//  KletRomicApp
//
//  Created by Borut on 11/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import Foundation

struct VinaModel {
    var nameVino: String
    var imageVino: String
    var detailVino: String
}
