//
//  ViewController.swift
//  PlavaTvornicaZadatakiOS
//
//  Created by Borut on 13/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import Alamofire
import GameplayKit

var USERS_NUMBER = ""
var USERS_GENDER = ""

class ViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource {
   
    @IBOutlet weak var btnSortOffRec: UIButton!
    @IBOutlet weak var btnSortAgeRef: UIButton!
    @IBOutlet weak var btnSortAbcRef: UIButton!
    @IBOutlet weak var sortMenu: NSLayoutConstraint!
    @IBOutlet weak var btnOpenViewForSort: UIButton!
    @IBOutlet weak var layoutSort: NSLayoutConstraint!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var collectionViewOfUsers: UICollectionView!
    @IBOutlet weak var btnGenderAny: UIButton!
    @IBOutlet weak var btnGenderFemale: UIButton!
    @IBOutlet weak var btnGenderMale: UIButton!
    @IBOutlet weak var txtFieldSearch: UITextField!
    lazy var listLayout: ListLayout = {
        var listLayout = ListLayout(itemHeight: 80)
        return listLayout
    }()
    var gridLayout: GridLayout!
    var sortMenuBar = false
    var activityIndicator:UIActivityIndicatorView = UIActivityIndicatorView()
    var listOfUsers = [UserModel]()
    var userData: UserModel!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.titleTextAttributes = [ NSAttributedStringKey.font: UIFont.systemFont(ofSize: 17, weight: UIFont.Weight.light)]
        collectionViewOfUsers.delegate = self
        collectionViewOfUsers.dataSource = self
        gridLayout = GridLayout(numberOfColumns: 2)
        collectionViewOfUsers.collectionViewLayout = gridLayout
        
        //search indicator
        activityIndicator.center = self.view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        view.addSubview(activityIndicator)
        
        // Shaping Buttons
        btnGenderAny.layer.cornerRadius = btnGenderAny.frame.size.width/7
        btnGenderAny.clipsToBounds = true
        btnGenderFemale.layer.cornerRadius = btnGenderFemale.frame.size.width/7
        btnGenderFemale.clipsToBounds = true
        btnGenderMale.layer.cornerRadius = btnGenderMale.frame.size.width/7
        btnGenderMale.clipsToBounds = true
        btnSearch.roundCorners(corners: [.topRight, .bottomRight], radius: 20)
        sortMenu.constant = 80
        let blueColor = hexStringToUIColor(hex: "#007AFF")
        let grayColor = hexStringToUIColor(hex: "#f1f1f2")
        btnGenderAny.backgroundColor = blueColor
        btnGenderMale.backgroundColor = grayColor
        btnGenderFemale.backgroundColor = grayColor
        btnSearch.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: UIFont.Weight.light)
        btnGenderAny.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
        btnGenderFemale.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
        btnGenderMale.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
        
        //customize textField for searching
        txtFieldSearch.layer.cornerRadius = btnGenderAny.frame.size.width/6
        txtFieldSearch.clipsToBounds = true
        txtFieldSearch.backgroundColor = grayColor
        let envelopeView = UIImageView(frame: CGRect(x: 5, y: 3, width: 14, height: 14))
        let image = UIImage(named: "Search")
        envelopeView.image = image
        let viewLeft: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        viewLeft.addSubview(envelopeView)
        txtFieldSearch.leftView = viewLeft
        txtFieldSearch.leftViewMode = UITextFieldViewMode.always
    
        self.hideKeyboardWhenTappedAround()
        //registering nib file
        self.collectionViewOfUsers.register(UINib(nibName:"ListCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "customCell")
    }
    
    //customize collectionView
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listOfUsers.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView.collectionViewLayout == gridLayout {
        if let cell = collectionViewOfUsers.dequeueReusableCell(withReuseIdentifier: "gridCell", for: indexPath as IndexPath) as? UserCollectionCellGrid {
            let users = listOfUsers[indexPath.row]
            cell.configureCell(someUsers: users)
            return cell
            }
        }else if collectionView.collectionViewLayout == listLayout {
            if let cell = collectionViewOfUsers.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath as IndexPath) as? ListCollectionViewCell {
                let users = listOfUsers[indexPath.row]
                cell.configureCell(someUsers: users)
                return cell
            }
        }
        return ListCollectionViewCell()
    }
    
    // switch between grid and list
    @IBAction func btnGridLayout(_ sender: Any) {
        UIView.animate(withDuration: 0.3, animations: {
            self.collectionViewOfUsers.collectionViewLayout.invalidateLayout()
            self.collectionViewOfUsers.setCollectionViewLayout(self.gridLayout, animated: false)
            self.collectionViewOfUsers.reloadData()
        })
    
    }
    @IBAction func btnListLayout(_ sender: Any) {
        UIView.animate(withDuration: 0.3, animations: {
            self.collectionViewOfUsers.collectionViewLayout.invalidateLayout()
            self.collectionViewOfUsers.setCollectionViewLayout(self.listLayout, animated: false)
            self.collectionViewOfUsers.reloadData()
        })
    
    }
    
    // button for number of users
    @IBAction func btnSearch(_ sender: Any) {
        activityIndicator.startAnimating()
//        let textfieldInt: Int? = Int(txtFieldSearch.text!)
//        if  textfieldInt! < 1 {
//            let alert = UIAlertController(title: "Error", message: "Please enter number bigger the 0", preferredStyle: UIAlertControllerStyle.alert)
//            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
//            var convertText = String(describing: textfieldInt)
//            convertText = ""
//            activityIndicator.stopAnimating()
//        } else {
           // let convertText = String(describing: textfieldInt)
        USERS_NUMBER = txtFieldSearch.text!
            dowloadDataForCollectionView {
                //book
                self.collectionViewOfUsers.reloadData()
            }
        USERS_NUMBER = ""
        txtFieldSearch.text = ""
       // }
    }
    
    // options in sorting menu
    @IBAction func btnSortAbc(_ sender: Any) {
        btnSortAbcRef.titleLabel?.font = UIFont.systemFont(ofSize: 25, weight: UIFont.Weight.regular)
        btnSortAgeRef.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.regular)
        btnSortOffRec.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.regular)
        listOfUsers.sort(by: {$0.firstName < $1.firstName})
        collectionViewOfUsers.reloadData()
    }
    
    @IBAction func sortByAge(_ sender: Any) {
        btnSortAbcRef.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.regular)
        btnSortAgeRef.titleLabel?.font = UIFont.systemFont(ofSize: 25, weight: UIFont.Weight.regular)
        btnSortOffRec.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.regular)
        listOfUsers.sort(by: {$0.userAge < $1.userAge})
        collectionViewOfUsers.reloadData()
    }
    @IBAction func sortOff(_ sender: Any) {
        btnSortAbcRef.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.regular)
        btnSortAgeRef.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.regular)
        btnSortOffRec.titleLabel?.font = UIFont.systemFont(ofSize: 25, weight: UIFont.Weight.regular)
        listOfUsers.shuffle()
        collectionViewOfUsers.reloadData()
    }
    
    
    // buttons for picking genders
    @IBAction func btnPickGender(_ sender: UIButton){
        let blueColor = hexStringToUIColor(hex: "#007AFF")
        let grayColor = hexStringToUIColor(hex: "#f1f1f2")
        let darkGray = hexStringToUIColor(hex: "363636")
        if sender.tag == 1 {
            USERS_GENDER = "any"
            btnGenderAny.backgroundColor = blueColor
            btnGenderMale.backgroundColor = grayColor
            btnGenderFemale.backgroundColor = grayColor
            btnGenderAny.setTitleColor(.white, for: .normal)
            btnGenderMale.setTitleColor(darkGray, for: .normal)
            btnGenderFemale.setTitleColor(darkGray, for: .normal)
            btnGenderFemale.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
            btnGenderMale.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
        } else if sender.tag == 2 {
            USERS_GENDER = "female"
            btnGenderAny.backgroundColor = grayColor
            btnGenderMale.backgroundColor = grayColor
            btnGenderFemale.backgroundColor = blueColor
            btnGenderFemale.setTitleColor(.white, for: .normal)
            btnGenderAny.setTitleColor(darkGray, for: .normal)
            btnGenderMale.setTitleColor(darkGray, for: .normal)
            btnGenderAny.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
            btnGenderMale.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
        } else if sender.tag == 3 {
            USERS_GENDER = "male"
            btnGenderAny.backgroundColor = grayColor
            btnGenderMale.backgroundColor = blueColor
            btnGenderFemale.backgroundColor = grayColor
            btnGenderMale.setTitleColor(.white, for: .normal)
            btnGenderAny.setTitleColor(darkGray, for: .normal)
            btnGenderFemale.setTitleColor(darkGray, for: .normal)
            btnGenderAny.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
            btnGenderMale.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
        }
        
    }
    // dowloading data for collectionView
    func dowloadDataForCollectionView(completed: @escaping DownloadComplete) {
        let someUsersTableView = URL(string: "https://randomuser.me/api/?results=\(USERS_NUMBER)&gender=\(USERS_GENDER)")
        Alamofire.request(someUsersTableView!).responseJSON { response in
            let result = response.result
            
            if let dict = result.value as? Dictionary<String, AnyObject> {
                if let list = dict["results"] as? [Dictionary< String, AnyObject>] {
                    for obj in list {
                        let userDeatils = UserModel(userDict: obj)
                        self.listOfUsers.append(userDeatils)
                    }
                }
            }
            completed()
            self.activityIndicator.stopAnimating()
        }
    }
    
    // button for opening menu with sort options
    @IBAction func btnShowSort(_ sender: Any) {
        if(sortMenuBar) {
            sortMenu.constant = 80
            btnOpenViewForSort.setTitle("Sort", for: .normal)
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
            })
        }else {
            btnOpenViewForSort.setTitle("Ok", for: .normal)
            sortMenu.constant = 0
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
            })
        }
        sortMenuBar = !sortMenuBar
    }
    
    // open DetailVC and send data
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let navigaton =  segue.destination as! DetailVC
        if segue.identifier == "gridSegue" && collectionViewOfUsers.collectionViewLayout == gridLayout{
                if let indexPath = self.collectionViewOfUsers.indexPath(for: sender as! UserCollectionCellGrid ) {
                    let selectedRow = listOfUsers[indexPath.row]
                    navigaton.currentUser = selectedRow
                    }
        } else if segue.identifier == "gridSegue" && collectionViewOfUsers.collectionViewLayout == listLayout {
            if let indexPath = self.collectionViewOfUsers.indexPath(for: sender as! ListCollectionViewCell ) {
                let selectedRow = listOfUsers[indexPath.row]
                navigaton.currentUser = selectedRow
            }
        }
        let backImage = UIImage(named: "back_icon")
        self.navigationController?.navigationBar.backIndicatorImage = backImage
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = backImage
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    // func for converting hex to string
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

// dissmis keyboard klick outside the textfield
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
// extension for shaping the buttons
extension UIButton{
    func roundCorners(corners:UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
}
//extension for shaping the textfield
extension UITextField{
    func roundCorners(corners:UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
}

extension Array
{
    /** Randomizes the order of an array's elements. */
    mutating func shuffle()
    {
        for _ in 0..<10
        {
            sort { (_,_) in arc4random() < arc4random() }
        }
    }
}



