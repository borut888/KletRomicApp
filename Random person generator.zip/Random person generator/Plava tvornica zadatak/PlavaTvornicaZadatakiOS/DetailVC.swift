//
//  DetailVC.swift
//  PlavaTvornicaZadatakiOS
//
//  Created by Borut on 14/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import MessageUI
import Contacts
import ContactsUI
import SDWebImage

class DetailVC: UIViewController,MFMailComposeViewControllerDelegate {

    @IBOutlet weak var imgGender: UIImageView!
    @IBOutlet weak var viewRightBottomCorner: UIView!
    @IBOutlet weak var imgUserDetail: UIImageView!
    @IBOutlet weak var lblUserFirstAndLastName: UILabel!
    @IBOutlet weak var btnPhoneNumber: UIButton!
    @IBOutlet weak var btnAdressStreet: UIButton!
    @IBOutlet weak var btnEmail: UIButton!
    @IBOutlet weak var lblUserAge: UILabel!
    @IBOutlet weak var viewLeftDownCorner: UIView!
    @IBOutlet weak var viewSmallLeftCorner: UIView!
    @IBOutlet weak var viewSmallRightCorner: UIView!
    @IBOutlet weak var viewUpLeftCorner: UIView!
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var imgFlags: UIImageView!
    
    var currentUser : UserModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Profile"
        self.navigationController?.navigationBar.titleTextAttributes = [ NSAttributedStringKey.font: UIFont.systemFont(ofSize: 17, weight: UIFont.Weight.light)]
        
        //putting data on view objects
        imgUserDetail.sd_setImage(with: URL(string: (currentUser?.userImage)!))
        lblUserFirstAndLastName.text = (currentUser?.firstName)! + " " + (currentUser?.lastName)!
        lblUserFirstAndLastName.font = UIFont.systemFont(ofSize: 20, weight: UIFont.Weight.semibold)
        btnPhoneNumber.setTitle("+385" + (currentUser?.userNumber)!, for: .normal)
        btnAdressStreet.setTitle(currentUser?.userStreet, for: .normal)
        btnEmail.setTitle(currentUser?.userEmail, for: .normal)
        setingUpFlags(flags: (currentUser?.userState)!)
        
        // fixing fonts
        lblUserFirstAndLastName.font = UIFont.systemFont(ofSize: 20, weight: UIFont.Weight.medium)
        btnSave.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: UIFont.Weight.medium)
        btnPhoneNumber.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: UIFont.Weight.light)
        btnAdressStreet.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: UIFont.Weight.light)
        btnEmail.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: UIFont.Weight.light)
        
        //customizing buttons, labels and image
        btnEmail.roundCorners(corners: [.topRight, .bottomRight], radius: 20)
        btnAdressStreet.roundCorners(corners: [.topRight, .bottomRight], radius: 20)
        btnPhoneNumber.roundCorners(corners: [.topRight, .bottomRight], radius: 20)
        lblUserFirstAndLastName.roundCorners(corners: [.topRight, .bottomRight], radius: 20)
        lblUserAge.roundCorners(corners: [.topLeft, .bottomLeft], radius: 20)
        btnEmail.titleLabel?.adjustsFontSizeToFitWidth = true;
        btnAdressStreet.titleLabel?.adjustsFontSizeToFitWidth = true;
        imgUserDetail.layer.cornerRadius = imgUserDetail.frame.size.width/2
        imgUserDetail.clipsToBounds = true
        imgFlags.layer.cornerRadius = imgFlags.frame.size.width/2
        imgFlags.clipsToBounds = true
        
        //changing color for genders
        if currentUser?.userGender == "male" {
            imgGender.image = UIImage(named: "male_icon")
            let blueColor = hexStringToUIColor(hex: "#007AFF")
            viewUpLeftCorner.backgroundColor = blueColor
            viewLeftDownCorner.backgroundColor = blueColor
            viewRightBottomCorner.backgroundColor = blueColor
            viewSmallLeftCorner.backgroundColor = blueColor
            viewSmallRightCorner.backgroundColor = blueColor
            lblUserFirstAndLastName.backgroundColor = blueColor
        } else if currentUser?.userGender == "female"{
            imgGender.image = UIImage(named: "female_icon")
            let pinkColor = hexStringToUIColor(hex: "#D00284")
            viewUpLeftCorner.backgroundColor = pinkColor
            viewLeftDownCorner.backgroundColor = pinkColor
            viewRightBottomCorner.backgroundColor = pinkColor
            viewSmallLeftCorner.backgroundColor = pinkColor
            viewSmallRightCorner.backgroundColor = pinkColor
            lblUserFirstAndLastName.backgroundColor = pinkColor
        }
        
        //customizing views
        setingUpViews(views: viewLeftDownCorner)
        setingUpViews(views: viewRightBottomCorner)
        setingUpViews(views: viewSmallLeftCorner)
        setingUpViews(views: viewSmallRightCorner)
        setingUpViews(views: viewUpLeftCorner)
        
        //converting date to years
        let ageComponents = currentUser?.userAge.components(separatedBy: "-")
        let dateDOB = Calendar.current.date(from: DateComponents(year:
            Int(ageComponents![0]), month: Int(ageComponents![1]), day:
            Int(ageComponents![2])))!
        lblUserAge.text = "\(dateDOB.age) yrs"
        
    }
    // option for calling user
    @IBAction func btnCallUser(_ sender: Any) {
        let phoneString = currentUser?.userNumber
        let url: NSURL = URL(string: "tel://+385" + phoneString!)! as NSURL
        UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
    }
    
    // option for sending mail
    @IBAction func btnSendEmail(_ sender: Any) {
        let email = currentUser?.userEmail
        let body = "Pozdrav od random usera"
        let coded = "mailto:\(email)?body=\(body)".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        if let url = URL(string: "mailto:" + coded!) {
            UIApplication.shared.open(url)
        }
    }
    
    // open mapVC and send data
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let navigaton =  segue.destination as! MapVC
        navigaton.currentLocation = currentUser?.userCity
    }
    
    // saving user in phonebook
    @IBAction func btnSaveUser(_ sender: Any) {
       
        let con = CNMutableContact()
        con.givenName = (currentUser?.firstName)!
        con.familyName = (currentUser?.lastName)!
        let data : Data = UIImagePNGRepresentation(imgUserDetail.image!)!
        con.imageData = data
        con.phoneNumbers.append(CNLabeledValue(
            label: "Contact", value: CNPhoneNumber(stringValue: (currentUser?.userNumber)!)))
        let unkvc = CNContactViewController(forUnknownContact: con)
        unkvc.contactStore = CNContactStore()
        unkvc.delegate = self as? CNContactViewControllerDelegate
        unkvc.allowsActions = false
        self.navigationController?.pushViewController(unkvc, animated: true)
    }
    
    // code for converting hex to string
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    // taking string and putting flag images
    func setingUpFlags(flags: String)  {
        if flags == "Cataluna" {
            imgFlags.image = UIImage(named: "cataluna_State_icon")
        } else if flags == "hessen" {
            imgFlags.image = UIImage(named: "hessen_icon_flag")
        }
        else if flags == "southland" {
            imgFlags.image = UIImage(named: "southland_state_icon")
        } else if flags == "valais" {
            imgFlags.image = UIImage(named: "valais_state_icon")
        }else if flags == "westmeath" {
            imgFlags.image = UIImage(named: "westmeath_state_icon")
        }
    }
    
    // func for setting up views
    func setingUpViews(views: UIView)  {
        views.layer.cornerRadius = views.frame.width/2
        views.clipsToBounds = true
    }
    
}

// extension for UILabel
extension UILabel{
    func roundCorners(corners:UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
}

