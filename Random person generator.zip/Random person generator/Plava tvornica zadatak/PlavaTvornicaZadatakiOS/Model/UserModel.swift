//
//  UserModel.swift
//  PlavaTvornicaZadatakiOS
//
//  Created by Borut on 13/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import Alamofire

typealias DownloadComplete = () -> ()

class UserModel {
    var _firstName: String!
    var _lastName: String!
    var _userImage: String!
    var _userNumber: String!
    var _userGender: String!
    var _userStreet: String!
    var _userEmail: String!
    var _userAge: String!
    var _userCity: String!
    var _userState: String!
    
    var firstName: String {
        if _firstName == nil {
            _firstName = "Borut"
        }
        let capitalLeter = _firstName.capitalizingFirstLetter()
        return capitalLeter
    }
    var lastName: String {
        if _lastName == nil {
            _lastName = "Persic"
        }
        let capitalLeter = _lastName.capitalizingFirstLetter()
        return capitalLeter
    }
    
    var userImage: String {
        if _userImage == nil {
            _userImage = "noImage"
        }
        return _userImage
    }
    var userNumber: String {
        if _userNumber == nil {
            _userNumber = "empty"
        }
        let userNumberFixedString =  _userNumber.replacingOccurrences(of: "-", with: "")
        return userNumberFixedString
    }
    
    var userGender: String {
        if _userGender == nil {
            _userGender = "empty"
        }
        return _userGender
    }
    var userStreet: String {
        if _userStreet == nil {
            _userStreet = "user is homeless"
        }
        return _userStreet
    }
    var userEmail: String {
        if _userEmail == nil {
            _userEmail = "no email"
        }
        return _userEmail
    }
    
    var userAge: String {
        if _userAge == nil {
            _userAge = "0 yrs"
        }
        return _userAge
    }
    var userCity: String {
        if _userCity == nil {
            _userCity = "virovitica"
        }
        return _userCity
    }
    var userState: String {
        if _userState == nil {
            _userState = "virovitica"
        }
        return _userState
    }
    
    init(userDict: Dictionary<String, AnyObject>) {
        if let results = userDict["name"] as? Dictionary<String, AnyObject>{
            if let firstName = results["first"] as? String {
                self._firstName = firstName
            }
        }
        if let results = userDict["name"] as? Dictionary<String, AnyObject>{
            if let lastName = results["last"] as? String {
                self._lastName = lastName
            }
        }
        if let results = userDict["picture"] as? Dictionary<String, AnyObject>{
            if let image = results["large"] as? String {
                self._userImage = image
            }
        }
        if let phone = userDict["phone"] as? String {
            self._userNumber = phone
            
        }
        if let gender = userDict["gender"] as? String {
            self._userGender = gender
        }
        if let results = userDict["location"] as? Dictionary<String, AnyObject>{
            if let street = results["street"] as? String {
                self._userStreet = street
            }
        }
        if let email = userDict["email"] as? String {
            self._userEmail = email
        }
        if let age = userDict["dob"] as? String {
            self._userAge = age
        }
        if let results = userDict["location"] as? Dictionary<String, AnyObject>{
            if let city = results["city"] as? String {
                self._userCity = city
            }
        }
        if let results = userDict["location"] as? Dictionary<String, AnyObject>{
            if let state = results["state"] as? String {
                self._userState = state
            }
        }
    }
    
}

extension Date {
    var age: Int {
        return Calendar.current.dateComponents([.year], from: self, to: Date()).year!
    }
}

extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + dropFirst()
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}

