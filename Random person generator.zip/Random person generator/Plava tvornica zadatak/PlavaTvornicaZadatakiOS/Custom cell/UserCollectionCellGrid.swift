//
//  UserCollectionCellGrid.swift
//  PlavaTvornicaZadatakiOS
//
//  Created by Borut on 16/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import SDWebImage

class UserCollectionCellGrid: UICollectionViewCell {
    
    @IBOutlet weak var viewInCell: UIView!
    @IBOutlet weak var userImg: UIImageView!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var userMail: UILabel!
    @IBOutlet weak var viewGenderColor: UIView!
    @IBOutlet weak var imgGender: UIImageView!
    
    override func awakeFromNib() {
        userImg.layer.cornerRadius = userImg.frame.size.width/2
        userImg.clipsToBounds = true
        viewGenderColor.layer.cornerRadius = viewGenderColor.frame.size.width/2
        viewGenderColor.clipsToBounds = true
        viewInCell.layer.cornerRadius = 10
        viewInCell.addShadowGrid(offset: CGSize.init(width: -2, height: 0), color: UIColor.black, radius: 3.0, opacity: 0.20)
        
    }
    
    // configuring cell for collectionView
    func configureCell(someUsers: UserModel) {
        userName.text = someUsers.firstName + " " + someUsers.lastName
        userMail.text = someUsers.userNumber
        userMail.font = UIFont.systemFont(ofSize: 10, weight: UIFont.Weight.light)
        userName.font = UIFont.systemFont(ofSize: 14, weight: UIFont.Weight.medium)
        userImg.sd_setImage(with: URL(string: someUsers.userImage))
        if someUsers.userGender == "male" {
            imgGender.image = UIImage(named: "male_icon")
            let blueColor = hexStringToUIColor(hex: "#007AFF")
            viewGenderColor.backgroundColor = blueColor
        } else if someUsers.userGender == "female"{
            imgGender.image = UIImage(named: "female_icon")
            let pinkColor = hexStringToUIColor(hex: "#D00284")
            viewGenderColor.backgroundColor = pinkColor
        }
    }
    
    // code for converting hex to string
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
// extension for view
extension UIView {
    func addShadowGrid(offset: CGSize, color: UIColor, radius: CGFloat, opacity: Float) {
        let layer = self.layer
        layer.masksToBounds = false
        layer.shadowOffset = offset
        layer.shadowColor = color.cgColor
        layer.shadowRadius = radius
        layer.shadowOpacity = opacity
        
        let backgroundCGColor = self.backgroundColor?.cgColor
        self.backgroundColor = nil
        layer.backgroundColor =  backgroundCGColor
    }
}
