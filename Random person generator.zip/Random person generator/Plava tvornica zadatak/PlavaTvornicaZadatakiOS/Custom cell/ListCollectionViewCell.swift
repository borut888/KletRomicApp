//
//  ListCollectionViewCell.swift
//  PlavaTvornicaZadatakiOS
//
//  Created by Borut on 17/02/2018.
//  Copyright © 2018 Borut. All rights reserved.
//

import UIKit
import SDWebImage
class ListCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var listImg: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblUserNumber: UILabel!
    @IBOutlet weak var viewOfList: UIView!
    @IBOutlet weak var genderColorVIew: UIView!
    @IBOutlet weak var imgGender: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        lblUserNumber.font = UIFont.systemFont(ofSize: 10, weight: UIFont.Weight.light)
        listImg.layer.cornerRadius = listImg.frame.size.width/2
        listImg.clipsToBounds = true
        //viewOfList.roundCornersForView(corners: [.topLeft, .bottomLeft], radius: 30)
        viewOfList.layer.cornerRadius = 35
        viewOfList.addShadowGrid(offset: CGSize.init(width: 0, height: 2), color: UIColor.black, radius: 3.0, opacity: 0.25)
    }
    
    // configuring cell for collectionView
    func configureCell(someUsers: UserModel) {
        lblUserName.text = someUsers.firstName + " " + someUsers.lastName
        lblUserNumber.text = someUsers.userNumber
        listImg.sd_setImage(with: URL(string: someUsers.userImage))
                if someUsers.userGender == "male" {
                    imgGender.image = UIImage(named: "male_icon")
                    let blueColor = hexStringToUIColor(hex: "#007AFF")
                    genderColorVIew.backgroundColor = blueColor
                } else if someUsers.userGender == "female"{
                    imgGender.image = UIImage(named: "female_icon")
                    let color1 = hexStringToUIColor(hex: "#D00284")
                    genderColorVIew.backgroundColor = color1
                }
    }
    
    // code for converting hex to string
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

// extension for shaping the view
extension UIView{
    func roundCornersForView(corners:UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
    func addShadow(offset: CGSize, color: UIColor, radius: CGFloat, opacity: Float) {
        let layer = self.layer
        layer.masksToBounds = false
        layer.shadowOffset = offset
        layer.shadowColor = color.cgColor
        layer.shadowRadius = radius
        layer.shadowOpacity = opacity
        
        let backgroundCGColor = self.backgroundColor?.cgColor
        self.backgroundColor = nil
        layer.backgroundColor =  backgroundCGColor
    }
}
